You must have nodejs to run this project. If you don't have it yet, you can install it from here:
https://nodejs.org/en/download/

This service consist in a collaborative to do list for the day where employees that work on a collavorative environment will be able to add the team to do actions and they would be printed and be visible for each one on the team. 

1. To run this service first run the following comand line code from the folder secondService:
node server

2. Then form the same folder, on a command line run the client and sent note parameter parameters:
node client {todo note}

example: node client email all prospects now

The line of code above would print the following line on the client side:

{"id":1,"text":"email all prospects now"}