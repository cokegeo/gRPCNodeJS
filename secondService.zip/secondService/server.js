//Import the modules
const grpc = require("grpc");
const protoLoader = require("@grpc/proto-loader")

//Reads to do proto
const packageDef = protoLoader.loadSync("todo.proto", {});

//Reads the services
const grpcObject = grpc.loadPackageDefinition(packageDef);
const todoPackage = grpcObject.todoPackage;

//Start server
const server = new grpc.Server();
server.bind("0.0.0.0:9001",
 grpc.ServerCredentials.createInsecure());

//Add services to server
server.addService(todoPackage.Todo.service,
    {
        "createTodo": createTodo,
        "readTodos" : readTodos,
        "readTodosStream": readTodosStream
    });

//Start server
server.start();

//Array of to do notes
const todos = []

//create a to do note
function createTodo (call, callback) {
    const todoItem = {
        "id": todos.length + 1,
        "text": call.request.text
    }
    todos.push(todoItem)
    callback(null, todoItem);
}

//read all the to do 
function readTodosStream(call, callback) {
    
    todos.forEach(t => call.write(t));
    call.end();
}
function readTodos(call, callback) {
    callback(null, {"items": todos})   
}