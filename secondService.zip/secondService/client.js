//import modules
const grpc = require("grpc");
const protoLoader = require("@grpc/proto-loader");
const packageDef = protoLoader.loadSync("todo.proto", {});
const grpcObject = grpc.loadPackageDefinition(packageDef);
const todoPackage = grpcObject.todoPackage;

//reads message passed on client into text constant
//message has to be on one word if adding more then one word, use _ or -
//Example: Send-email-to-prospects-before-lunch
//const text = process.argv[2];

//create text array
var text = [];

//Process the input values and add them to the array (text)
process.argv.forEach((val, index) => {
    text.push(val);
  });

//removes first and second values of the array (node client)
text.shift();
text.shift();

//Gets all the array words together and add the space separator between words
text = text.join(' ');


const client = new todoPackage.Todo("localhost:9001", 
grpc.credentials.createInsecure());

//log message for testing
//console.log(text)

//add new to do to the list
client.createTodo({
    "id": -1,
    "text": text
}, (err, response) => {

    console.log("Recieved from server " + JSON.stringify(response));
});

//read all to dos on client side
const call = client.readTodosStream();
call.on("data", item => {
    console.log("received item from server " + JSON.stringify(item));
});

call.on("end", e => console.log("To do added!"));