You must have nodejs to run this project. If you don't have it yet, you can install it from here:
https://nodejs.org/en/download/

This service consist in verifying the employees holidays left/accumulated so they can easily access from designated tablets around the office, instead of having to log into a thrird party web application for checking.

1. To run this service first run the following comand line code from the folder fourthService:
node server

2. Then form the same folder, on a command line run the client and sent the id and username parameters. On this example the id within the 5000 employees. The id "874663337" is a master service that returns all the employees information:
node client {employeeId}

example: node client 1
example master: node client 874663337