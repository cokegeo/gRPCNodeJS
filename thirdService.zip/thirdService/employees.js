const employees = [
    {
		id: 1,
		daysLeft: 10,
		username: "Coke",
	},
    {
			id: 20,
			daysLeft: 5,
			username: "Thomas",
	},
    {
			id: 30,
			daysLeft: 23,
			username: "Jorge",
	}
];

exports.employees = employees;