'use strict';

//import modules
const fs = require('fs');
const grpc = require('grpc');
const loader = require('@grpc/proto-loader');

//reads proto file and services
const packageDefinition = loader.loadSync('messages.proto', {
  keepCase: false,
  longs: String,
  enums: String, 
  defaults: true,
  oneofs: true
});

//loads services into pkg
const pkg = grpc.loadPackageDefinition(packageDefinition);

//create server and assign port for server service
const PORT = 9002;
const client = new pkg.EmployeeService(`localhost:${PORT}`, grpc.credentials.createInsecure());

//reads the parameter sent when running the client (employee id)
const option = parseInt(process.argv[2]);

//check if client call corresponds to get by id or get all employees' details
if (option<= 5000 && option>0){
    getById(client);
}else if (option == 874663337){
    getAll(client);
    console.log("Master log: Retrieving all employees details...")
}else{
    console.log("Invalid ID");
}

//server streaming client call that retrieves the employees details
function getAll(client) {
    const call = client.getAll({});

    call.on('data', function (data) {
        console.log(data.employee);
    });
}

//Unary call to validate id and retrieve details of corresponding employee
function getById(client) {
    client.getById({id: option}, function (err, response) {
        if (err) {
            //Error to display on client side.
            console.log("The Id: "+ option + " does't match any user. Please try again");
        } else {
            console.log(response.employee);
        }
    });
}