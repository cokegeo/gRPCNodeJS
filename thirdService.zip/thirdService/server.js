'use strict';

//import modules
const fs = require('fs');
const grpc = require('grpc');
const loader = require('@grpc/proto-loader');
const packageDefinition = loader.loadSync('messages.proto', {
  keepCase: false,
  longs: String,
  enums: String, 
  defaults: true,
  oneofs: true
});

//load services
const pkg = grpc.loadPackageDefinition(packageDefinition);

//reads employees internal db document
const employees = require('./employees').employees;

const PORT = 9002;

//Creates the new server
const server = new grpc.Server();

//Services
server.addService(pkg.EmployeeService.service, {
  getById: getById,
  getAll: getAll,
});

//bind the server on local host and port using constant PORT
//IMPORTANT: for passing conts variables use ´´ in comments instead of ''
server.bind(`localhost:${PORT}`, grpc.ServerCredentials.createInsecure());
console.log(`Welcome, the server is running on port ${PORT}`);
//starts the server
server.start();

//server function to check if id matches employees db
function getById(call, callback){

  const id = call.request.id;
    for (let i = 0; i < employees.length; i++) {
        if (employees[i].id === id) {
            callback(null, {employee: employees[i]});
            return;
        }else{
          //error response on server side informing id tried
          console.log("Invalid ID tried: "+ call.request.id);
        }
    }

  callback('Invalid Id');
}

function getAll(call){
  employees.forEach(function(emp) {
    call.write({employee: emp});
});

call.end();
}