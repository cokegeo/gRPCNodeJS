'use strict';

//Use to read file employees.js
const fs = require('fs');

// Use GRPC, Proto Loader, reads the proto file and defines the option parameters
// https://github.com/grpc/grpc-node/blob/master/packages/proto-loader/README.md
const grpc = require('grpc');
const loader = require('@grpc/proto-loader');
const packageDefinition = loader.loadSync('messages.proto', {
  keepCase: false,
  longs: String,
  enums: String, 
  defaults: true,
  oneofs: true
});

const pkg = grpc.loadPackageDefinition(packageDefinition);

//loads file employees.js
const employees = require('./employees').employees;

const PORT = 9002;

//Creates the new server
const server = new grpc.Server();

//Services
server.addService(pkg.EmployeeService.service, {
  getById: getById,
  getAll: getAll,
});

//bind the server on local host and port using constant PORT
//IMPORTANT: for passing conts variables use ´´ in comments instead of ''
server.bind(`localhost:${PORT}`, grpc.ServerCredentials.createInsecure());
console.log(`Welcome, the server is running on port ${PORT}`);

//starts the server
server.start();

//Get employees by ID
function getById(call, callback){

  //gets the id and username from the client paramenters
  const id = call.request.id;
  const username = call.request.username;

    //goes through ids and usernames checking for match
    for (let i = 0; i < employees.length; i++) {
        if (employees[i].id === id) {
          if(employees[i].username === username) {
            callback(null, {employee: employees[i]});
            return;
          }else{
            console.log("Username doesn't match any user");
          }
        }else{
          console.log("ID doesn't match any user ID");
        }
    }
  callback("Invalid ID");
}

//print all employees and show if they have access using username property (Boolean)
function getAll(call){
  employees.forEach(function(emp) {
    call.write({employee: emp});
    return;
});
call.end();
}