'use strict';

const fs = require('fs');
const grpc = require('grpc');
const loader = require('@grpc/proto-loader');
const packageDefinition = loader.loadSync('messages.proto', {
  keepCase: false,
  longs: String,
  enums: String, 
  defaults: true,
  oneofs: true
});

const pkg = grpc.loadPackageDefinition(packageDefinition);

const PORT = 9002;

const client = new pkg.EmployeeService(`localhost:${PORT}`, grpc.credentials.createInsecure());

//Check parameters sent on client call node client {checkID} {checkUser}
const checkID = parseInt(process.argv[2]);
const checkUser = process.argv[3];

//checks if ID is between range of employees
//Using only 9 for this project
if (checkID<= 9 && checkID>0){
    getById(client);
    console.log("You have used the user: " + checkUser);

//Checks if user correspond to master user
}else if (checkID == 874663337){
    getAll(client);
    console.log("You have used the Master User");

}else{
    console.log("Invalid ID or Username");
}

console.log("You have used the id: " + checkID);

//Gets all employees
function getAll(client) {
    const call = client.getAll({});
    call.on('data', function (data) {
        console.log(data.employee);
    });
}

//Get employee by Id and check if username matches to retrieve if employee is authorised
function getById(client) {
    client.getById({id: checkID, username: checkUser}, function (err, response) {
        if (err) {
            console.log("Either ID or Username is invalid. Try again");
        } else {
            console.log(response.employee);
        }
    });
}

