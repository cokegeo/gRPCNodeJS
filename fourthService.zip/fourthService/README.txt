You must have nodejs to run this project. If you don't have it yet, you can install it from here:
https://nodejs.org/en/download/

This server consist in verifying the employees and see if they have access to some files and rooms in the company, veryfying their id and username.

1. To run this service first run the following comand line code from the folder fourthService:
node server

2. Then form the same folder, on a command line run the client and sent the id and username parameters. On this example the id will verify only form 1 to 9 and "874663337" is a master service that returns all the employees access:
node client {employeeId} {username}

example: node client 1 Coke
example master: node client 874663337