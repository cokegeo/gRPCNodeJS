const employees = [
    {
		id: 1,
		authorised: true,
		username: "Coke",
	},
    {
			id: 2,
			authorised: true,
			username: "Thomas",
	},
    {
			id: 3,
			authorised: false,
			username: "Jorge",
	}
];

exports.employees = employees;