const employees = [
    {
		id: 1,
		badgeNumber: 2080,
		firstName: "Coke",
		lastName: "Orellana",
		vacationAccrualRate: 2,
		vacationAccrued: 30,
	},
    {
		id: 2,
		badgeNumber: 7538,
		firstName: "Jorge",
		lastName: "Orellana",
		vacationAccrualRate: 2.3,
		vacationAccrued: 23.4,
	},
    {
		id: 3,
		badgeNumber: 5144,
		firstName: "Julianne",
		lastName: "Lyne",
		vacationAccrualRate: 3,
		vacationAccrued: 31.7,
	}
];

exports.employees = employees;